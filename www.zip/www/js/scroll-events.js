$(window).bind('mousewheel', parent.scrollEvent);
$(window).bind('touchstart', parent.touchStart);
$(window).bind('touchend', parent.touchEnd);